package com.ichooseyou;

public enum Region {
    KANTO, JHOTO, HOENN, SINNOH, UNOVA, KALOS, ALOLA, GALAR, PALDEA
}