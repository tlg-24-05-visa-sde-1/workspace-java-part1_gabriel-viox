/*
 * This is the classic HelloWorld application in Java
 * This is run as a standalone application, not on a server
 */
class HelloWorld {
    //starting point/entry point for every standalone Java application
    public static void main(String[] args) {
        System.out.println("Hello from IntelliJ !!!");// prints to console
        System.out.println("This is nicer than bare metal programming?!");
    }
}